/* Fichier: bonjour.c
* affiche 'Bonjour le Monde!!!' à l'écran.
* auteur: Julie Ludwig et Guillaume Bufferne
*/

#include <stdio.h> 

int main() {
printf("Bonjour le Monde !!!");
return 0; }