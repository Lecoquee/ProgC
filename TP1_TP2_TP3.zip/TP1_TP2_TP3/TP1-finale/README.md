# Bibliothèques
* stdio.h
*

# Références
* Rien
*

# Difficulté
* Facile

# Commentaires
* RAS
* 
