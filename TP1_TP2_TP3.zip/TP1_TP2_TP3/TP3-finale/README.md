# Bibliothèques
* stdio.h
* stdlib.h
* time.h
*

# Références
* Rien
*

# Difficulté
* Moyen-Difficle

# Commentaires
* RAS
* 
