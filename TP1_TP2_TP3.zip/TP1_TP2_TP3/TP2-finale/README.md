# Bibliothèques
* stdio.h
* stdlib.h
*

# Références
* Rien
*

# Difficulté
* Moyen

# Commentaires
* RAS
* 